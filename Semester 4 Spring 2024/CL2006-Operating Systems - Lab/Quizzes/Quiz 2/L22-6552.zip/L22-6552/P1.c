#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdbool.h>
#include <sys/types.h>
#include<sys/stat.h>
#include <ctype.h>
#include <pthread.h>

int main(int argc,char*argv[])
{
    if(argc!=2)
    {
        printf("Error! give 1 argument\n");
        return 0;
    }

    int Npipe=open("namedPipe",O_RDWR);

    if(Npipe==-1)
    {
        printf("Error! named pipe not opening in P1\n");
        return 0;
    }
    int pipe1[2];
    int pipe2[2];

    pipe(pipe1);
    pipe(pipe2);

    pid_t pid=fork();

    if(pid==-1)
    {
        printf("Fork failed in P1\n");
        return 0;
    }
    else if(pid==0)
    {
        int signal;
        int sum=-1;
        read(pipe1[0],&signal,sizeof(int));
        read(Npipe,&sum,sizeof(int));
        write(pipe2[1],&sum,sizeof(int));

    }
    else
    {
        int size=strlen(argv[1]);
        write(Npipe,&size,sizeof(int)); // send size of data
        write(Npipe,argv[1],size); // send data (file name)
        sleep(3);
        int signal=1;
        write(pipe1[1],&signal,sizeof(int));
        wait(NULL);
        int sum=-1;

        
        read(pipe2[0],&sum,sizeof(int));
        
        printf("P1 recived from child: %d\n",sum);


    }
    close(Npipe);
    return 0;


}