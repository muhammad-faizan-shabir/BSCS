#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdbool.h>
#include <sys/types.h>
#include<sys/stat.h>
#include <ctype.h>
#include <pthread.h>
FILE* file;
int sum=0;
void * worker(void *param)
{
    int num;
    while (fscanf(file, "%d", &num) != EOF) {
        sum += num;
    }
    pthread_exit(NULL);


}
int main(int argc,char*argv[])
{
    int Npipe=open("namedPipe",O_RDWR);
    int size;
    char buffer[1000];
    read(Npipe,&size,sizeof(int));
    read(Npipe,buffer,size);
    buffer[size]='\0';
    
    file = fopen(buffer, "r");

    
    
    pthread_t id;
    pthread_create(&id,NULL,worker,NULL);

    pthread_join(id,NULL);

    write(Npipe,&sum,sizeof(int));
    printf("The sum in P2: %d\n",sum);
    close(Npipe);
    return 0;
}