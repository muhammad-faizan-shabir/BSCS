#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

#define BUFFER_SIZE 20

void reverseString(char* str) {
    int i=0;
    int j=BUFFER_SIZE-1;

    while(i<=j)
    {
        char temp=str[i];
        str[i]=str[j];
        str[j]=temp;
        i++;
        j--;

    }
}

int main() {

    pid_t pid;
    char buffer[BUFFER_SIZE];
    
    int pipe1[2];// Create pipe
    int pipe2[2];//-----
    pipe(pipe1);//TO DO
    pipe(pipe2);//-----

    pid=fork();// Fork a child process
    //-----
    //TO DO
    //-----

    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    
    if (pid > 0) { // Parent process

        printf("____P2 Parent Started____\n");
        close(pipe1[0]);
        close(pipe2[1]);
        int r1=open("R1.txt",O_RDONLY);

        read(r1,buffer,BUFFER_SIZE);
        write(pipe1[1],buffer,BUFFER_SIZE);
        wait(NULL);

        read(pipe2[0],buffer,BUFFER_SIZE);

        int r2 =open("R2.txt",O_WRONLY);
        write(r2,buffer,BUFFER_SIZE);

        close(r1);
        close(r2);

        //-----
        //TO DO
        //-----

        printf("____P2 Parent Ended____\n");

        exit(EXIT_SUCCESS);

    } else { // Child process

        
        printf("____P2 Child Started____\n");
        close(pipe1[1]);
        close(pipe2[0]);
        read(pipe1[0],buffer,BUFFER_SIZE);

        

        

        //-----
        //TO DO
        //-----

        printf("Child received string from parent: %s\n", buffer);
        reverseString(buffer);

        write(pipe2[1],buffer,BUFFER_SIZE);
        //-----
        //TO DO
        //-----

        printf("Child send string to parent: %s\n", buffer);
        
        printf("____P2 Child Ended____\n");

        exit(EXIT_SUCCESS);
    }
    
    return 0;
}
