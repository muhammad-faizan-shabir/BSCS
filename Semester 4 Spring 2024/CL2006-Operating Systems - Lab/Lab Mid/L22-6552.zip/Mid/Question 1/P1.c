#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

#define BUFFER_SIZE 20

void modifyString(char* str) {
    for(int i=0;i<BUFFER_SIZE;i++)
        {
            if((!(str[i]>='a' && str[i]<='z'))||(!(str[i]>='A' && str[i]<='Z')))
            {
                if((i%2)==0)
                {
                    str[i]='-';

                }
                else
                {
                    str[i]='.';

                }
            }
        }
}

int main (){
    
    pid_t pid;
    char buffer[BUFFER_SIZE];
    char data[] = "123456789|.abcdefjhi";

    int pipe1[2];// Create pipe
    int pipe2[2];//-----
    pipe(pipe1); // write for parent read for child
    pipe(pipe2);// read for parent write for child

    pid =fork();// Fork a child process
    //-----
    //TO DO
    //-----

    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { 
        
        // Child process
        close(pipe1[1]);
        close(pipe2[0]);
       


        printf("____P1 Child Started____\n");
        int signal;
        read(pipe1[0],&signal,sizeof(int));
        if(signal!=1)
        {
            printf("Signal not recieved from parent a\n");
            exit(1);

        }
        int r3= open("R3.txt",O_RDONLY);
        read(r3,buffer,BUFFER_SIZE);
        modifyString(buffer);

        

        write(pipe2[1],buffer,BUFFER_SIZE);
        close(r3);

        //-----
        //TO DO
        //-----

        printf("____P1 Child Ended____\n");

        exit(EXIT_SUCCESS);
        
    } else { 
        // Parent process
        close(pipe1[0]);
        close(pipe2[1]);
        int signal=1;
        
        

        printf("____P1 Parent Started____\n");
        int r1=open("R1.txt",O_WRONLY);
        write(r1,data,BUFFER_SIZE);
        write(pipe1[1],&signal,sizeof(int));


        //-----
        //TO DO
        //-----

        printf("Child received string from parent: %s\n", data);
        wait(NULL);
        read(pipe2[0],buffer,BUFFER_SIZE);
        
        //-----
        //TO DO
        //-----

        printf("Child send string to parent: %s\n", buffer);
        int result=open("Results.txt",O_WRONLY);

        write(result,buffer,BUFFER_SIZE);
        close(result);
        close(r1);
        printf("____P1 Parent Ended____\n");

        exit(EXIT_SUCCESS);
    }

    return 0;
}

