#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

#define BUFFER_SIZE 20

void modifyString(char* str, int incrementer_value) {
    for(int i=0;i<BUFFER_SIZE;i++)
    {
        str[i]=str[i]+incrementer_value;
    }
    //-----
    //TO DO
    //-----
}

int main() {

    pid_t pid;
    char buffer[BUFFER_SIZE];
    char data[] = "ihjfedcba.|987654321";
    
    int pipe1[2];// Create pipe
    int pipe2[2];//-----
    pipe(pipe1);//TO DO
    pipe(pipe2);//-----

    pid=fork();// Fork a child process
    //-----
    //TO DO
    //-----
    
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) { // Parent process

        printf("____P3 Parent Started____\n");
        int r2=open("R2.txt",O_RDONLY);
        read(r2,buffer,BUFFER_SIZE);
        write(pipe1[1],buffer,BUFFER_SIZE);
        wait(NULL);

        read(pipe2[0],buffer,BUFFER_SIZE);

        int r3=open("R3.txt",O_WRONLY);
        write(r3,buffer,BUFFER_SIZE);
        close(r2);
        close(r3);

        //-----
        //TO DO
        //-----

        printf("____P3 Parent Ended____\n");

        exit(EXIT_SUCCESS);

    } else { // Child process
        
        printf("____P3 Child Started____\n");

        read(pipe1[0],buffer,BUFFER_SIZE);


        //-----
        //TO DO
        //-----

        printf("Child received string from parent: %s\n", buffer);
        int incrementValue=3;
        for(int i=0;i<BUFFER_SIZE;i++)
        {
            if(buffer[i]!=data[i])
            {
                incrementValue=2;
                break;
            }
        }

        modifyString(buffer,incrementValue);
        //-----
        //TO DO
        //-----
        write(pipe2[1],buffer,BUFFER_SIZE);

        printf("Child send string to parent: %s\n", buffer);
        
        printf("____P3 Child Ended____\n");

        exit(EXIT_SUCCESS);
    }
    
    return 0;
}
